import 'package:flutter/material.dart';
import 'RadioButton.dart';

class CalculadoraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        //backgroundColor: Colors.grey,
        appBar: AppBar(
          title: const Text('Prova 1: Calculadora Dart/Flutter'),
        ),
        body: Calculate(),
      ),
    );
  }
}

class Calculate extends StatefulWidget {
  @override
  State<Calculate> createState() {
    return CalculateState();
  }
}

class CalculateState extends State<Calculate> {
  String CampoNumero1 = '';
  String CampoNumero2 = '';
  String CampoResultado = '';
  String op = '+';
  final GlobalKey<FormState> _formKey = GlobalKey<FormState>();
  TextEditingController controller = TextEditingController();

  String? Validacao(value) {
    final possibleNumber = num.tryParse(value);
    if (possibleNumber == null) {
      return '"$value" não é um parâmetro válido';
    }
    return null;
  }

  Widget buildCampoNumero1() {
    return TextFormField(
      decoration: InputDecoration(
        hintText: 'Insira o primeiro número',
        enabledBorder: OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.black)),
        focusedBorder: const OutlineInputBorder(
            borderSide: const BorderSide(color: Colors.white)),
      ),
      keyboardType: TextInputType.number,
      validator: Validacao,
      onSaved: (value) => setState(() => CampoNumero1 = value!),
    );
  }

  Widget buildCampoNumero2() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Insira o segundo número'),
      keyboardType: TextInputType.number,
      validator: Validacao,
      onSaved: (value) => setState(() => CampoNumero2 = value!),
    );
  }

  ValueChanged<String?> _valueChangedHandler() {
    return (value) => setState(() => op = value!);
  }

  Widget buildCampoRadio() {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10.0, 8.0, 100.0, 8.0),
      child: Column(
        children: [
          MyRadioOption<String>(
            value: '+',
            groupValue: op,
            onChanged: _valueChangedHandler(),
            label: '+',
            text: 'Adição',
          ),
          MyRadioOption<String>(
            value: '-',
            groupValue: op,
            onChanged: _valueChangedHandler(),
            label: '-',
            text: 'Subtração',
          ),
          MyRadioOption<String>(
            value: '*',
            groupValue: op,
            onChanged: _valueChangedHandler(),
            label: '*',
            text: 'Multiplicação',
          ),
          MyRadioOption<String>(
            value: '/',
            groupValue: op,
            onChanged: _valueChangedHandler(),
            label: '/',
            text: 'Divisão',
          ),
        ],
      ),
    );
  }

  Widget buildCampoResultado() {
    return TextFormField(
      decoration: InputDecoration(labelText: 'Resultado'),
      controller: controller,
    );
  }

  String result() {
    double n1 = double.parse(CampoNumero1);
    double n2 = double.parse(CampoNumero2);
    var result;
    if (op == '+') {
      result = n1 + n2;
    } else if (op == '-') {
      result = n1 - n2;
    } else if (op == '*') {
      result = n1 * n2;
    } else if (op == '/') {
      result = n1 / n2;
    }
    return result.toString();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Container(
          child: Form(
            key: _formKey,
            child: ListView(
              padding: const EdgeInsets.fromLTRB(50.0, 8.0, 50.0, 8.0),
              children: <Widget>[
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(80.0, 8.0, 50.0, 8.0),
                      child: Text(
                        'Número 1:',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    buildCampoNumero1(),
                  ],
                ),
                Row(
                  children: [
                    Padding(
                      padding: const EdgeInsets.fromLTRB(80.0, 8.0, 50.0, 8.0),
                      child: Text(
                        'Número 2:',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    buildCampoNumero2(),
                  ],
                ),
                SizedBox(height: 30),
                Row(
                  children: [
                    Padding(
                      padding:
                          const EdgeInsets.fromLTRB(100.0, 8.0, 100.0, 8.0),
                      child: Text(
                        'Escolha a operação desejada:',
                        style: TextStyle(
                          color: Colors.black,
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                    ),
                    buildCampoRadio(),
                  ],
                ),
                SizedBox(height: 50),
                Padding(
                    padding: const EdgeInsets.fromLTRB(350.0, 8.0, 350.0, 8.0),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.center,
                      children: [
                        ElevatedButton(
                            style: OutlinedButton.styleFrom(
                              primary: Colors.white,
                              backgroundColor: Colors.lightBlue.shade700,
                              onSurface: Colors.black,
                              elevation: 20,
                              shadowColor: Colors.blue,
                              shape: RoundedRectangleBorder(
                                  borderRadius: BorderRadius.circular(30)),
                            ),
                            child: Text('Executar',
                                style: TextStyle(
                                    color: Colors.white,
                                    fontSize: 16,
                                    fontWeight: FontWeight.bold)),
                            onPressed: () {
                              final isValid = _formKey.currentState!.validate();
                              if (isValid) {
                                _formKey.currentState!.save();
                                setState(() {
                                  controller.text = result();
                                });
                              }
                            }),
                      ],
                    )),
                SizedBox(height: 50),
                buildCampoResultado(),
              ],
            ),
          ),
        ),
      );
}
