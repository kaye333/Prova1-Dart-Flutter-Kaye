import 'package:flutter/material.dart';
import 'calc.dart';

void main() => runApp(CalculadoraApp());
